from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement

import chromedriver_autoinstaller

chromedriver_autoinstaller.install(True)

import time
from urllib import parse

import sys

# with open("keyword.txt", "r", encoding="utf-8") as f:
#     keyword = f.read()

# with open("info.txt", "r", encoding="utf-8") as f:
#     url = f.read()

keyword = sys.argv[1]
url = sys.argv[2]

encodedKeyword = parse.quote(keyword)

options = Options()
options.add_argument("--headless")

driver = Chrome(options=options)

driver.get(f"https://search.naver.com/search.naver?query={encodedKeyword}&nso=&where=blog&sm=tab_opt")

time.sleep(3)

for i in range(3):
    for pageDown in range(10):
        driver.find_element_by_tag_name("body").send_keys(Keys.PAGE_DOWN)

        time.sleep(0.2)

time.sleep(3)

lineList: list[WebElement] = driver.execute_script("return document.getElementsByClassName(\"api_txt_lines\")")

rankCount = 1

for line in lineList:
    try:
        if line.get_attribute("href") != None:
            if url in line.get_attribute("href"):    
                print(line.get_attribute("href"), rankCount)
                break 

            rankCount += 1
    except:
        pass 


driver.close()