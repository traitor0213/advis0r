import threading
from flask import Flask, request, send_file
from os import system

from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement

import chromedriver_autoinstaller

chromedriver_autoinstaller.install(True)

from urllib import parse

import sys
import time

app = Flask(__name__)

idList: list[dict] = []

def _getNaverBlogRank(keyword: str, url: str, requestId: str):

    encodedKeyword = parse.quote(keyword)

    options = Options()
    options.add_argument("--headless")

    driver = Chrome(options=options)

    driver.get(f"https://search.naver.com/search.naver?query={encodedKeyword}&nso=&where=blog&sm=tab_opt")

    time.sleep(3)

    for i in range(3):
        for pageDown in range(10):
            driver.find_element_by_tag_name("body").send_keys(Keys.PAGE_DOWN)

            time.sleep(0.2)

    time.sleep(3)

    lineList: list[WebElement] = driver.execute_script("return document.getElementsByClassName(\"api_txt_lines\")")

    rankCount = 1

    href = ""

    for line in lineList:
        try:
            if line.get_attribute("href") != None:
                if url in line.get_attribute("href"):    
                    print(line.get_attribute("href"), rankCount)
                    href = line.get_attribute("href")
                    break 

                rankCount += 1
        except:
            pass 

    for idInfo in idList:
        if requestId == idInfo["id"]:
            idInfo["result"] = f"RANKED AT: {rankCount}, URL: {href}"

    driver.close()

@app.route("/get/naver/blog/rank", methods=["GET"])
def getNaverBlogRank():
    args = request.args.to_dict()

    keyword = args["keyword"]
    url = args["url"]

    requestId = str(time.time())
    threading.Thread(target=_getNaverBlogRank, args=(keyword, url, requestId)).start()

    idList.append({"id":requestId, "result": ""})

    return requestId

@app.route("/get/naver/blog/rank/result", methods=["GET"])
def getNaverBlogRankResult():
    args = request.args.to_dict()
    
    for idInfo in idList:
        if args["id"] == idInfo["id"]:
            return idInfo["result"]
        
    return ""

@app.route("/")
def main():
    return send_file("index.html")

@app.route("/input")
def inputer():
    return send_file("input.html")

app.run("0.0.0.0", 9000)